#!/usr/bin/env python
import rospy
from sensor_msgs.msg import Image
from countpeople_msgs.msg import array
import cv2,cv_bridge
import numpy as np


class Cameras:
    def __init__(self):
        self.bridge = cv_bridge.CvBridge()
        self.nameCamera = rospy.get_param("/cameraID", "camera1")
        self.image_sub = rospy.Subscriber("/usb_cam/image_raw", Image, self.image_callback)
        self.posx = 0
        self.posy = 0
        self.pubCoord = rospy.Publisher("/coord", array, queue_size = 10)
        self.pubmsg = array()
        self.pubmsg.header.frame_id = 'camera0'
        rospy.loginfo("ok...")

    def image_callback(self, msg):
        image = self.bridge.imgmsg_to_cv2(msg, desired_encoding = 'bgr8')
        hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
        verde_bajos = np.array([49,50,50], dtype=np.uint8)
        verde_altos = np.array([80, 255, 255], dtype=np.uint8)
        mask = cv2.inRange(hsv, verde_bajos, verde_altos)
        moments = cv2.moments(mask)
        area = moments['m00']
        if(area > 5000):
            self.posx = int(moments['m10']/moments['m00'])
            self.posy = int(moments['m01']/moments['m00'])
            cv2.rectangle(image, (self.posx, self.posy), (self.posx+2, self.posy+2),(0,0,255), 2)
        self.pubmsg.header.seq += 1
        self.pubmsg.header.stamp = rospy.Time.now()
        self.pubmsg.data = [self.posx, self.posy]
        self.pubCoord.publish(self.pubmsg)
        
##        cv2.imshow('imagen',image)
##        cv2.waitKey(1)

rospy.init_node('Cameras')


cameras = Cameras()
rospy.spin()
