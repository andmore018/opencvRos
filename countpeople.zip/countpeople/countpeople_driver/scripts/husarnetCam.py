#!/usr/bin/env python
import sys, time
import rospy
import roslib
import numpy as np
from sensor_msgs.msg import CompressedImage
#from sensor_msgs.msg import Image
import cv2,cv_bridge

VERBOSE = False

class Cameras:
    def __init__(self):
        #self.image_pub = rospy.Publisher("/output/image_raw/compressed",CompressedImage)
        self.subscriber = rospy.Subscriber("/celtavo/camera0/image/compressed",
                                           CompressedImage, self.image_callback, queue_size = 1)
        if VERBOSE:
            print("subscribed to camera compressed")
        #self.bridge = cv_bridge.CvBridge()
        #self.nameCamera = rospy.get_param("/cameraID", "camera1")
        #self.image_sub = rospy.Subscriber("/{}/usb_cam/image_raw".format(self.nameCamera), Image, self.image_callback)
        rospy.loginfo("ok...")

    def image_callback(self, msg):
        if VERBOSE:
            print('image of type = "%s"' % msg.format)
        np_arr = np.fromstring(msg.data, np.uint8)
        img_np = cv2.imdecode(np_arr, cv2.CV_LOAD_IMAGE_COLOR)
        #image = self.bridge.imgmsg_to_cv2(msg, desired_encoding = 'bgr8')
        cv2.imshow("camera0", img_np)
        cv2.waitKey(1)

##        msg = CompressedImage()
##        msg.header.stamp = rospy.Time.now()
##        msg.format = "jpeg"
##        msg.data = np.array(cv2.imencode('.jpg', image_np)[1]).tostring()
##        self.image_pub.publish(msg)
def main(args):
    initClass = Cameras()
    rospy.init_node('Cameras',anonymous=True)
    try:
        rospy.spin()
    except KeyboardInterrupt:
        print("off...")
    cv2.destroyAllWindows()
        
if __name__ == '__main__':
    main(sys.argv)


