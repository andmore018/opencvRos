#!/usr/bin/env python
import rospy
#from sensor_msgs.msg import Image
from countpeople_msgs.msg import array
from std_msgs.msg import String
#import cv2,cv_bridge
#import numpy as np


class Coordenadas:
    def __init__(self):
        self.coor_sub = rospy.Subscriber('/coord', array, self.coor_callback)
        
        rospy.loginfo("ok...")

    def coor_callback(self, msg):
        posx = msg.data[0]
        posy = msg.data[1]
        rospy.loginfo('{} , {}'.format(posx,posy))
##

##def coor_callback(msg):
##    posx = msg.data[0]
##    posy = msg.data[1]
##    print(0)
##    
##
##if __name__ == '__main__':
##    try:
##        rospy.init_node('Coordenadas')
##        rospy.loginfo("ok...")
##        rospy.Subscriber('coord', array, coor_callback)
##        rospy.spin()
##    except rospy.ROSInterruptException:
##        rospy.logerr('error')

rospy.init_node('Coordenadas')
coordenadas = Coordenadas()
rospy.spin()
